package com.example.carhelper.util;

public interface Converter {

    default double convertSpeed(double speed, Unit from, Unit to) {
        return speed;
    }
}
