package com.example.carhelper.data;

import android.os.Handler;
import android.os.SystemClock;

import com.example.carhelper.service.CarData;

import static com.example.carhelper.util.Constants.UPDATE_PERIOD;

class SinusGenerator implements DataGenerator {

    private long t = 0;

    // To transform [-1,1] to [0, 180] for speed
    // and to [0, 90] for tachometer
    private final int a = 90;
    private final int b = 90;
    private double speed = -1;
    private double prm = -1;
    private DataListener mDataListener;
    private Handler mHandler;
    private final long PERIOD_UPDATE = UPDATE_PERIOD;

    public SinusGenerator() {
        mHandler = new Handler();
    }

    @Override
    public void start(boolean start) {
        if (start) {
            mHandler.post(task);
        } else {
            mHandler.removeCallbacksAndMessages(null);
        }
    }

    @Override
    public void setDataChangeListener(DataListener listener) {
        mDataListener = listener;
    }

    @Override
    public double getPRM() {
        return prm;
    }

    @Override
    public double getSpeed() {
        return speed;
    }

    @Override
    public void generate() {
        t = SystemClock.elapsedRealtime();
        double time_val = Math.sin(t);
        double transformed = a * time_val + b;
        SinusGenerator.this.prm = transformed / 2;
        SinusGenerator.this.speed = transformed;
    }

    Runnable task = new Runnable() {
        @Override
        public void run() {
            generate();
            mDataListener.onDataUpdated(new CarData(getSpeed(), getPRM()));
            mHandler.postDelayed(task, PERIOD_UPDATE);
        }
    };
}
