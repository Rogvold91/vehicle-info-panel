package com.example.carhelper.util;

public interface LabelConverter {
    String getLabelFor(double progress, double maxProgress);
}
