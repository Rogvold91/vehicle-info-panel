package com.example.carhelper.service;

public class SpeedServiceWrapper {


}
