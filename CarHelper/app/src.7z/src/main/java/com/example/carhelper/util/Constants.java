package com.example.carhelper.util;

import android.graphics.Color;

public class Constants {

    // Drawing constants
    public static final double DEFAULT_MAX_SPEED = 100.0;
    public static final double DEFAULT_MAJOR_TICK_STEP = 20.0;
    public static final int DEFAULT_MINOR_TICKS = 1;
    public static final int DEFAULT_LABEL_TEXT_SIZE_DP = 12;
    public static final int DEFAULT_UNITS_TEXT_SIZE_DP = 24;
    public static final int DEFAULT_COLOR = Color.rgb(180, 180, 180);
    //

    public static final long UPDATE_PERIOD = 100;

    public static final long ANIMATION_DURATION = 30;
    public static final long ANIMATION_DELAY = 0;

    public static final String KMH = "Km/H";
    public static final String MPH = "MPH";

}
