package com.example.carhelper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.carhelper.service.SpeedService;

public class bootcomplete extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent startService = new Intent(context, SpeedService.class);
        context.startForegroundService(startService);
    }
}
