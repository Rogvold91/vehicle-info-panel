package com.example.carhelper.util;

public enum TypeControl {
    Speedometer, Tachometer
}
