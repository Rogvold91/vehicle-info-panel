package com.example.carhelper.data;

class TrivialGenerator implements DataGenerator {

    private DataListener mDataListerner;

    @Override
    public void start(boolean start) {

    }

    @Override
    public void setDataChangeListener(DataListener listener) {
        mDataListerner = listener;
    }

    @Override
    public void generate() {

    }
}
