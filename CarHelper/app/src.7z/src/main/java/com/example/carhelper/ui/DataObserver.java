package com.example.carhelper.ui;

import com.example.carhelper.service.CarData;

public interface DataObserver {
    void onCarDataUpdated(CarData data);
}
