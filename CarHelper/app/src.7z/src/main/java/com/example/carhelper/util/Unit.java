package com.example.carhelper.util;

enum Unit {
    SI, Empire
}
