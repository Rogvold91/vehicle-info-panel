package com.example.carhelper.data;

public class SourceFabric {

    public static DataGenerator buildGenerator() {
        return new SinusGenerator();
    }
}
