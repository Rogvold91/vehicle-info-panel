package com.example.carhelper.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.example.carhelper.R;
import com.example.carhelper.data.DataGenerator;
import com.example.carhelper.data.DataListener;
import com.example.carhelper.data.SourceFabric;

import java.util.ArrayList;
import java.util.List;

import static com.example.carhelper.util.Remote.tryExec;

public class SpeedService extends Service implements DataListener {

    private static final String TAG = SpeedService.class.getSimpleName();
    private static final int NOTIFICATION_ID = 1;

    private final List<IDataCallback> mDataCallbacks = new ArrayList<>();
    private DataGenerator mGenerator;

    public SpeedService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.v(TAG, "Service has been created");
        String notificationIdString =
                getResources().getString(R.string.vehicle_helper);
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        NotificationChannel notificationChannel =
                new NotificationChannel(
                        notificationIdString,
                        "Car Pseudo cluster",
                        NotificationManager.IMPORTANCE_NONE);
        notificationManager.createNotificationChannel(notificationChannel);
        Notification notification =
                new Notification.Builder(
                        this, notificationIdString).setSmallIcon(R.drawable.ic_launcher_background).build();

        startForeground(NOTIFICATION_ID, notification);
        mGenerator = SourceFabric.buildGenerator();
        mGenerator.setDataChangeListener((data) -> onDataUpdated(data));
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }


    private final ISpeedService.Stub mBinder = new ISpeedService.Stub() {
        @Override
        public void addCallback(IDataCallback callback) {
            Log.d(TAG, "New Callback has been added");
            mDataCallbacks.add(callback);
        }

        @Override
        public void removeCallback(IDataCallback callback) {
            Log.d(TAG, "Callback has been removed");
            mDataCallbacks.remove(callback);
        }

        @Override
        public void startStopSimulation(boolean start) {
            Log.d(TAG, "Start simulation: " + start);
            mGenerator.start(start);
        }
    };

    @Override
    public void onDataUpdated(CarData data) {
        for (IDataCallback callback: mDataCallbacks) {
            tryExec(() -> callback.vehicleDataChanged(data));
        }
    }
}
