package com.example.carhelper.data;

import com.example.carhelper.service.CarData;

public interface DataListener {

    void onDataUpdated(CarData data);
}
